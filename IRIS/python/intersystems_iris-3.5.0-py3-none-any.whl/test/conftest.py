import pytest

def pytest_addoption(parser):
    group = parser.getgroup("iris")

    group.addoption(
        "--embedded",
        action="store_true",
        help="Use embedded mode",
    )

    group.addoption(
        "--iris-host",
        action="store",
        default='localhost',
        help="Hostname",
    )

    group.addoption(
        "--iris-port",
        action="store",
        default=1972,
        type=int,
        help="Port",
    )

    group.addoption(
        "--iris-namespace",
        action="store",
        default='USER',
        help="Namespace",
    )

    group.addoption(
        "--iris-username",
        action="store",
        default='_SYSTEM',
        help="Username",
    )

    group.addoption(
        "--iris-password",
        action="store",
        default='SYS',
        help="Password",
    )
